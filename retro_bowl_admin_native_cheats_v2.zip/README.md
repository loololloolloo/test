Retro Bowl HTML5 native-runtime mod

This build keeps the supplied GameMaker HTML5 runtime and applies cheats inside its native save-data load path.

Controls: Ctrl+O opens the retro-style admin panel. A/D movement mapping is removed.

Player speed range: 1-500. Max Stats and OP Mode modify the actual roster/save structures, then persist through the game's own save system.
