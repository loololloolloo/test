'use strict';
const canvas=document.getElementById('game'),ctx=canvas.getContext('2d',{alpha:false});ctx.imageSmoothingEnabled=false;
const A='assets/';
const manifestPromise=fetch(A+'sprite_manifest.json').then(r=>r.json());
const assets={}; const imgs=assets;
const names=['spr_field','spr_ball','spr_run','spr_qb_aim','spr_qb_throw','spr_qb_walk','spr_jump_catch','spr_stand_ball','spr_run_ball'];
function load(n){return new Promise((ok,bad)=>{const im=new Image();im.onload=()=>{assets[n]=im;ok(im)};im.onerror=()=>bad(new Error('missing '+n));im.src=A+n})}
let W=0,H=0,dpr=1;function resize(){dpr=Math.min(devicePixelRatio||1,3);W=innerWidth;H=innerHeight;canvas.width=Math.ceil(W*dpr);canvas.height=Math.ceil(H*dpr);canvas.style.width=W+'px';canvas.style.height=H+'px';ctx.setTransform(dpr,0,0,dpr,0,0)}addEventListener('resize',resize);resize();
const key=new Set();addEventListener('keydown',e=>{key.add(e.key.toLowerCase());if([' ','arrowup','arrowdown','arrowleft','arrowright'].includes(e.key.toLowerCase()))e.preventDefault()});addEventListener('keyup',e=>key.delete(e.key.toLowerCase()));
let M=null;
const player={x:410,y:118,dir:1,frame:0,anim:0,throwT:0,charge:0,hasBall:true};
const receiver={x:890,y:118,dir:-1,frame:0,anim:0,catchT:0,hasBall:false};
const ball={x:420,y:108,z:0,vx:0,vy:0,vz:0,frame:0,anim:0,flight:false,held:true};
const field={w:1300,h:237};
function k(...a){return a.some(x=>key.has(x));}
function spriteFrame(name,i){const m=M[name];return m&&m.frames[i%m.frames.length]}
function drawSprite(name,i,x,y,scale,flip=1){const m=M[name],f=spriteFrame(name,i);if(!m||!f||!imgs[f.file])return;const im=imgs[f.file];const [tx,ty,tw,th]=f.target;ctx.save();ctx.translate(x,y);if(flip<0)ctx.scale(-1,1);ctx.drawImage(im,0,0,im.width,im.height,-m.origin[0]*scale+tx*scale,-m.origin[1]*scale+ty*scale,im.width*scale,im.height*scale);ctx.restore()}
function movePlayer(dt){
 // Preserve the recovered throw-state model: movement is optional, but the QB is stationary by default.
 let dx=(k('d','arrowright')?1:0)-(k('a','arrowleft')?1:0),dy=(k('s','arrowdown')?1:0)-(k('w','arrowup')?1:0);
 if(dx||dy){const n=Math.hypot(dx,dy);player.x=Math.max(80,Math.min(field.w-80,player.x+dx/n*75*dt));player.y=Math.max(45,Math.min(195,player.y+dy/n*55*dt));player.dir=dx<0?-1:dx>0?1:player.dir;player.anim+=dt;if(player.anim>.1){player.frame=(player.frame+1)%6;player.anim=0}}
 else player.frame=0;
}
function release(){if(!ball.held||player.throwT>0)return;let dx=(k('d','arrowright')||k('arrowleft')||k('arrowup')||k('arrowdown'))?((k('d','arrowright')?1:0)-(k('a','arrowleft')?1:0)):player.dir;let dy=(k('s','arrowdown')?1:0)-(k('w','arrowup')?1:0);if(!dx&&!dy)dx=player.dir;const n=Math.hypot(dx,dy)||1;const power=155+player.charge*205;ball.held=false;ball.flight=true;player.hasBall=false;player.throwT=.32;ball.x=player.x+player.dir*10;ball.y=player.y-5;ball.z=7;ball.vx=dx/n*power;ball.vy=dy/n*power;ball.vz=95+player.charge*65;player.charge=0}
let wasCharge=false;function update(dt){
 movePlayer(dt);
 const charging=k(' ','enter'); if(ball.held&&charging){player.charge=Math.min(1,player.charge+dt*1.25);wasCharge=true}else if(ball.held&&wasCharge){release();wasCharge=false}
 if(player.throwT>0)player.throwT=Math.max(0,player.throwT-dt);
 if(ball.held){ball.x=player.x+player.dir*11;ball.y=player.y-5;ball.z=5;ball.anim+=dt;if(ball.anim>.1){ball.frame=(ball.frame+1)%6;ball.anim=0}}
 if(ball.flight){ball.x+=ball.vx*dt;ball.y+=ball.vy*dt;ball.z+=ball.vz*dt;ball.vz-=290*dt;ball.anim+=dt;if(ball.anim>.1){ball.frame=(ball.frame+1)%6;ball.anim=0}
   const d=Math.hypot(ball.x-receiver.x,ball.y-receiver.y);
   if(d<22&&ball.z<28){ball.flight=false;ball.held=true;ball.x=receiver.x-8;ball.y=receiver.y-4;receiver.catchT=.28;receiver.hasBall=true;ball.vx=ball.vy=ball.vz=0}
   if(ball.z<=0){ball.z=0;ball.flight=false;ball.vx*=.55;ball.vy*=.55}
 }
 if(receiver.catchT>0)receiver.catchT=Math.max(0,receiver.catchT-dt);
 // Receiver stays planted; only reacts with recovered catch animation when the ball reaches the catch window.
 receiver.frame=receiver.catchT>0?Math.min(4,Math.floor((.28-receiver.catchT)/.056)):0;
}
function render(){
 ctx.setTransform(dpr,0,0,dpr,0,0);ctx.fillStyle='#000';ctx.fillRect(0,0,W,H);
 const scale=Math.max(1,Math.min(3.8,W/field.w,H/field.h));
 const ox=(W-field.w*scale)/2,oy=(H-field.h*scale)/2;
 // exact extracted field frame, scaled to fill the browser viewport without a black letterbox when possible
 const f=M.spr_field.frames[0],im=imgs[f.file];ctx.drawImage(im,ox+f.target[0]*scale,oy+f.target[1]*scale,f.target[2]*scale,f.target[3]*scale);
 drawSprite('spr_run',player.frame,ox+player.x*scale,oy+player.y*scale,scale,player.dir);
 if(ball.held && player.charge>0.02)drawSprite('spr_qb_aim',Math.floor(player.charge*6),ox+player.x*scale,oy+player.y*scale,scale,player.dir);
 if(player.throwT>0)drawSprite('spr_qb_throw',0,ox+player.x*scale,oy+player.y*scale,scale,player.dir);
 drawSprite('spr_jump_catch',receiver.frame,ox+receiver.x*scale,oy+receiver.y*scale,scale,receiver.dir);
 drawSprite('spr_ball',ball.frame,ox+ball.x*scale,oy+(ball.y-ball.z)*scale,scale,1);
}
async function start(){M=await manifestPromise;const all=[];for(const n of names){for(const f of M[n].frames)if(!imgs[f.file])all.push(load(f.file))}await Promise.all(all);let t=performance.now();function loop(now){const dt=Math.min(.033,(now-t)/1000);t=now;update(dt);render();requestAnimationFrame(loop)}requestAnimationFrame(loop)}start().catch(e=>{document.body.textContent=e.stack||e});
