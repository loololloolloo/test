(function(){
  'use strict';
  var KEY='RB_ADMIN_CFG_V1';
  function load(){try{return JSON.parse(localStorage.getItem(KEY)||'{}')}catch(e){return {}}}
  function save(c){try{localStorage.setItem(KEY,JSON.stringify(c));}catch(e){}}
  window.__RB_ADMIN_CFG=load(); window.__RB_ADMIN_CFG.enabled=true;
  var css=document.createElement('style');css.textContent=`#rb-admin{position:fixed;inset:0;background:rgba(0,0,0,.58);display:none;align-items:center;justify-content:center;z-index:2147483647;font-family:monospace;color:#fff}#rb-admin.open{display:flex}#rb-panel{width:min(560px,92vw);background:#3168f4;border:5px solid #fff;box-shadow:8px 8px 0 #07152f;image-rendering:pixelated;padding:18px 22px 22px;box-sizing:border-box}#rb-title{font-size:30px;font-weight:900;letter-spacing:2px;text-align:center;margin:0 0 16px;text-shadow:3px 3px 0 #0b2a72}#rb-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}#rb-panel button,#rb-panel input[type=range]{font:inherit}#rb-panel button{background:#3168f4;color:#fff;border:4px solid #fff;border-right-color:#132c64;border-bottom-color:#132c64;padding:11px 10px;font-weight:900;cursor:pointer;min-height:48px}#rb-panel button:active{border-color:#132c64 #fff #fff #132c64}#rb-panel label{display:block;border:4px solid #fff;padding:10px;font-weight:900;grid-column:1/-1}.rb-value{float:right}.rb-note{font-size:12px;opacity:.9;text-align:center;margin-top:12px}#rb-close{grid-column:1/-1}`;document.head.appendChild(css);
  var wrap=document.createElement('div');wrap.id='rb-admin';wrap.innerHTML='<div id="rb-panel"><div id="rb-title">ADMIN MENU</div><div id="rb-grid"><label>PLAYER SPEED <span class="rb-value" id="rb-speed-v">10</span><input id="rb-speed" type="range" min="1" max="10" value="10" style="width:100%"></label><button id="rb-max">MAX ALL STATS</button><button id="rb-op">OP MODE</button><button id="rb-save">APPLY + RELOAD</button><button id="rb-reset">RESET CHEATS</button><button id="rb-close">CLOSE</button></div><div class="rb-note">CTRL+O toggles this menu</div></div>';document.body.appendChild(wrap);
  var speed=wrap.querySelector('#rb-speed'),sv=wrap.querySelector('#rb-speed-v');
  var cfg=window.__RB_ADMIN_CFG||{}; speed.value=cfg.speedStat||10;sv.textContent=speed.value;
  speed.oninput=function(){sv.textContent=speed.value;cfg.speedStat=Number(speed.value);cfg.enabled=true;window.__RB_ADMIN_CFG=cfg;save(cfg)};
  wrap.querySelector('#rb-max').onclick=function(){cfg.enabled=true;cfg.maxStats=true;save(cfg);flash('MAX STATS ENABLED — APPLY + RELOAD')};
  wrap.querySelector('#rb-op').onclick=function(){cfg.enabled=true;cfg.maxStats=true;cfg.opMode=true;cfg.speedStat=10;speed.value=10;sv.textContent='10';save(cfg);flash('OP MODE ENABLED — APPLY + RELOAD')};
  wrap.querySelector('#rb-save').onclick=function(){save(cfg);location.reload()};
  wrap.querySelector('#rb-reset').onclick=function(){cfg={enabled:false,speedStat:10,maxStats:false,opMode:false};save(cfg);location.reload()};
  wrap.querySelector('#rb-close').onclick=function(){wrap.classList.remove('open')};
  wrap.addEventListener('click',function(e){if(e.target===wrap)wrap.classList.remove('open')});
  document.addEventListener('keydown',function(e){if(e.ctrlKey&&e.key.toLowerCase()==='o'){e.preventDefault();wrap.classList.toggle('open')}});
  function flash(t){var old=document.getElementById('rb-toast');if(old)old.remove();var d=document.createElement('div');d.id='rb-toast';d.textContent=t;d.style='position:fixed;left:50%;bottom:24px;transform:translateX(-50%);z-index:2147483648;background:#fff;color:#07152f;border:4px solid #07152f;padding:10px 14px;font:900 14px monospace;';document.body.appendChild(d);setTimeout(function(){d.remove()},1800)}
  // Remove accidental keyboard focus stealing from the game while the panel is open.
  wrap.addEventListener('keydown',function(e){e.stopPropagation()},true);
})();