(function(){
  'use strict';
  var KEY='RB_ADMIN_CFG_V2';
  function load(){try{return JSON.parse(localStorage.getItem(KEY)||'{}')}catch(e){return {}}}
  function save(c){try{localStorage.setItem(KEY,JSON.stringify(c));}catch(e){}}
  var cfg=load(); if(!cfg.enabled) cfg={enabled:false,speedEnabled:false,speed:100,maxStats:false,opMode:false};
  window.__RB_ADMIN_CFG=cfg;
  var css=document.createElement('style');css.textContent=`#rb-admin{position:fixed;inset:0;background:rgba(0,0,0,.60);display:none;align-items:center;justify-content:center;z-index:2147483647;font-family:monospace;color:#fff}#rb-admin.open{display:flex}#rb-panel{width:min(600px,94vw);max-height:90vh;overflow:auto;background:#3168f4;border:5px solid #fff;box-shadow:8px 8px 0 #07152f;image-rendering:pixelated;padding:18px 22px 22px;box-sizing:border-box}#rb-title{font-size:30px;font-weight:900;letter-spacing:2px;text-align:center;margin:0 0 16px;text-shadow:3px 3px 0 #0b2a72}#rb-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}#rb-panel button,#rb-panel input{font:inherit}#rb-panel button{background:#3168f4;color:#fff;border:4px solid #fff;border-right-color:#132c64;border-bottom-color:#132c64;padding:11px 10px;font-weight:900;cursor:pointer;min-height:48px}#rb-panel button:active{border-color:#132c64 #fff #fff #132c64}#rb-panel label{display:block;border:4px solid #fff;padding:10px;font-weight:900;grid-column:1/-1}.rb-value{float:right}.rb-note{font-size:12px;opacity:.9;text-align:center;margin-top:12px}.rb-status{grid-column:1/-1;border:4px solid #fff;padding:8px;text-align:center;font-weight:900}#rb-close{grid-column:1/-1}`;document.head.appendChild(css);
  var wrap=document.createElement('div');wrap.id='rb-admin';wrap.innerHTML='<div id="rb-panel"><div id="rb-title">ADMIN MENU</div><div id="rb-grid"><label>PLAYER SPEED % <span class="rb-value" id="rb-speed-v">10</span><input id="rb-speed" type="range" min="1" max="500" value="100" style="width:100%"></label><div class="rb-status" id="rb-status">NATIVE GAME CODE MODIFIER: OFF</div><button id="rb-speed-on">APPLY SPEED</button><button id="rb-max">MAX ALL STATS</button><button id="rb-op">OP MODE</button><button id="rb-save">SAVE CHEATS + RELOAD</button><button id="rb-reset">RESET CHEATS</button><button id="rb-close">CLOSE</button></div><div class="rb-note">CTRL+O toggles this menu • changes are applied by the actual GameMaker save-data loader</div></div>';document.body.appendChild(wrap);
  var speed=wrap.querySelector('#rb-speed'),sv=wrap.querySelector('#rb-speed-v'),status=wrap.querySelector('#rb-status');
  speed.value=Math.max(1,Math.min(500,Number(cfg.speed)||100));sv.textContent=speed.value;
  function statusText(){var a=[];if(cfg.speedEnabled)a.push('SPEED '+cfg.speed+'%');if(cfg.maxStats)a.push('MAX STATS');if(cfg.opMode)a.push('OP MODE');status.textContent=a.length?'NATIVE GAME CODE MODIFIER: '+a.join(' • '):'NATIVE GAME CODE MODIFIER: OFF';}
  speed.oninput=function(){sv.textContent=speed.value};
  wrap.querySelector('#rb-speed-on').onclick=function(){cfg.enabled=true;cfg.speedEnabled=true;cfg.speed=Number(speed.value);window.__RB_ADMIN_CFG=cfg;save(cfg);statusText();flash('SPEED '+cfg.speed+'% QUEUED')};
  wrap.querySelector('#rb-max').onclick=function(){cfg.enabled=true;cfg.maxStats=true;cfg.speedEnabled=true;cfg.speed=Number(speed.value);window.__RB_ADMIN_CFG=cfg;save(cfg);statusText();flash('MAX STATS QUEUED')};
  wrap.querySelector('#rb-op').onclick=function(){cfg.enabled=true;cfg.opMode=true;cfg.maxStats=true;cfg.speedEnabled=true;cfg.speed=Number(speed.value);window.__RB_ADMIN_CFG=cfg;save(cfg);statusText();flash('OP MODE QUEUED')};
  wrap.querySelector('#rb-save').onclick=function(){save(cfg);location.reload()};
  wrap.querySelector('#rb-reset').onclick=function(){localStorage.removeItem(KEY);location.reload()};
  wrap.querySelector('#rb-close').onclick=function(){wrap.classList.remove('open')};
  wrap.addEventListener('click',function(e){if(e.target===wrap)wrap.classList.remove('open')});
  document.addEventListener('keydown',function(e){if(e.ctrlKey&&e.key.toLowerCase()==='o'){e.preventDefault();wrap.classList.toggle('open');statusText()}});
  function flash(t){var old=document.getElementById('rb-toast');if(old)old.remove();var d=document.createElement('div');d.id='rb-toast';d.textContent=t;d.style='position:fixed;left:50%;bottom:24px;transform:translateX(-50%);z-index:2147483648;background:#fff;color:#07152f;border:4px solid #07152f;padding:10px 14px;font:900 14px monospace;';document.body.appendChild(d);setTimeout(function(){d.remove()},1800)}
  statusText();
})();