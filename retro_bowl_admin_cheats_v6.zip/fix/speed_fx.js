(()=>{
'use strict';
window.__RB_SPEED_FX=window.__RB_SPEED_FX||{trail:[],enabled:true};
const fx=window.__RB_SPEED_FX;
function cfg(){return window.__RB_ADMIN_CFG||{};}
function loop(){
  const c=cfg();
  const boosted=!!(c.enabled&&c.speedEnabled&&Number(c.speed)>100);
  fx.enabled=boosted;
  if(boosted){
    // The GameMaker player runtime exposes the controlled instance through its live ball/player links.
    // The trail is deliberately a render-only effect and never changes gameplay state.
    fx.trail.push({t:performance.now()});
    if(fx.trail.length>14) fx.trail.shift();
  } else fx.trail.length=0;
  requestAnimationFrame(loop);
}
loop();
})();
