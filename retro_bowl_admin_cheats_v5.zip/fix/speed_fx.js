(()=>{
// controlled-player-only visual boost layer
window.__RB_SPEED_FX={trail:[],enabled:true};
let c=document.querySelector('canvas');
function tick(){
 if(!c){requestAnimationFrame(tick);return;}
 // runtime hook reads __RB_ADMIN_CFG; this layer never touches other instances
 requestAnimationFrame(tick);
}
tick();
})();
