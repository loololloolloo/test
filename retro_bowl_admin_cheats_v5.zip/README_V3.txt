Retro Bowl HTML5 Admin Cheats V3

This build patches the actual GameMaker HTML5 runtime (html5game/RetroBowl.js).

Ctrl+O opens the admin menu.
Player Speed is a percentage multiplier from 1% to 500%, where 100% is normal and 500% is 5x normal movement acceleration.
Max All Stats and OP Mode are applied to the GameMaker roster/save data during the native savegame load path.

Important: this is not a Canvas recreation and does not replace the GameMaker runtime.
